<?php

/**
 * Plugin Name: Network Site Stats
 * Description: Plugin giúp Super Admin theo dõi tình trạng các trang web con.
 * Version:     1.0.0
 * Author:      Sinh Viên IT
 * Network:     true
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'network_admin_menu', 'nss_add_menu' );

function nss_add_menu() {
    add_menu_page(
        'Thống kê Mạng lưới',
        'Site Stats',
        'manage_network', 
        'network-site-stats',
        'nss_render_page',
        'dashicons-chart-pie',
        30
    );
}

function nss_render_page() {
    if ( ! current_user_can( 'manage_network' ) ) wp_die( 'Không có quyền truy cập.' );
    ?>
    <div class="wrap">
        <h1>Thống kê Mạng lưới Website</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên Site (Blog Name)</th>
                    <th>Số lượng bài viết</th>
                    <th>Ngày đăng bài mới nhất</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sites = get_sites();

                if ( ! empty( $sites ) ) {
                    foreach ( $sites as $site ) {
                        $site_id = $site->blog_id;
                        $blog_details = get_blog_details( $site_id );

                        switch_to_blog( $site_id );

                        $count_posts = wp_count_posts( 'post' );
                        $published = $count_posts->publish;
                        $latest_date = 'Chưa có bài viết';
                        $recent = wp_get_recent_posts( [ 'numberposts' => 1, 'post_status' => 'publish' ] );
                        if ( ! empty( $recent ) ) {
                            $latest_date = date( 'd/m/Y H:i', strtotime( $recent[0]['post_date'] ) );
                        }

                        restore_current_blog();
                        ?>
                        <tr>
                            <td><strong><?php echo esc_html( $site_id ); ?></strong></td>
                            <td><?php echo esc_html( $blog_details->blogname ); ?></td>
                            <td><?php echo esc_html( $published ); ?></td>
                            <td><?php echo esc_html( $latest_date ); ?></td>
                        </tr>
                        <?php
                    }
                } else {
                    echo '<tr><td colspan="4">Không có dữ liệu.</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}